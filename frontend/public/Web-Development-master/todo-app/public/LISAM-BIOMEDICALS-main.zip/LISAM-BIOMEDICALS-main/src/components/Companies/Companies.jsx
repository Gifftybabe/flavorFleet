import React from "react";
import "./Companies.css";
const Companies = () => {
  return (
    <section className="c-wrapper">
      <div className="paddings innerWidth flexCenter c-container">
        <img src="./char.png" alt="" />
        <img src="./G-system.png" alt="" />
        <img src="./zenith-life.webp" alt="" />
        <img src="./excel.png" alt="" />
      </div>
    </section>
  );
};

export default Companies;
